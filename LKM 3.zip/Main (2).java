import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input data belanja
        System.out.print("Masukan total belanja: ");
        int totalBelanja = scanner.nextInt();

        // Input data penggunaan member
        System.out.print("Apakah menggunakan member? (y/n): ");
        char menggunakanMember = scanner.next().charAt(0);

        // Hitung diskon
        int diskon = 0;
        if (menggunakanMember == 'y') {
            if (totalBelanja > 100000 && totalBelanja <= 500000) {
                diskon = 15000;
            } else if (totalBelanja > 500000) {
                diskon = 50000;
            }
        } else {
            if (totalBelanja > 100000) {
                diskon = 5000;
            }
        }

        // Cetak total belanja setelah diskon
        System.out.println("Total belanja setelah diskon: " + (totalBelanja - diskon));
    }
}